#pragma once

class BlittersFix
{
public:
	static void Apply();
};
