Description
------

This font is essentially a vanilla font with fixed characters and added Unicode cyrillics range.

Changelog
------

Version 4:
- Added a emoji (`⛏ U+26CF`) for Phobos default harvester counter label.

Version 3:
- Added two emojis (`⌚ U+231A` and `⚡ U+26A1`) for Phobos default extended tooltip labels.

Versions 1-2:
- Initial partial overhaul of existing characters and fully drawn Unicode Cyrillics.

Credits
-------
Kerbiter#3128
wiktorderelf#6546
Uranusian#0653